<template>
  <div class="container">
    <div class="menu-bar">
    <div>
      <div class="login-out" style="float: right">
        <el-button type="danger" @click="handleLoginOut">退出登录</el-button>
      </div>
      <div style="float: right;margin-left: 40%" ><span >{{userinfo}}</span></div>
    </div>
    </div>


<div style="width: 600px;margin-top: 40px;position: relative;">
    <el-form >
      <el-form-item label="姓名:" label-width="200px">
        <span >{{info.name}}</span>
      </el-form-item>
      <el-form-item label="年龄:" label-width="200px">
        <span >{{info.age}}</span>
      </el-form-item>
      <el-form-item label="性别:" label-width="200px">
        <span >{{info.gender}}</span>
      </el-form-item>
      <el-form-item label="地址:" label-width="200px">
        <span >{{info.accountAddress}}</span>
      </el-form-item>
      <el-form-item label="身份证号:" label-width="200px">
        <span >{{info.id}}</span>
      </el-form-item>
    </el-form>
    <div style="position: absolute;margin-left: 50%;left: -100px;width: 200px;display: flex;justify-content: center;">
        <el-button type="primary" @click="onSubmit">立即挂号</el-button>
        <el-button type="primary" @click="b_onSubmit">我的病历</el-button>
    </div>
  </div>


    <el-dialog title="预约、挂号" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item  label="医院" label-width="200px">
          <el-input  v-model="form.hospitalName" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="科室" label-width="200px">
          <el-input v-model="form.department" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="createAppointment"
        >确 定</el-button
        >
      </div>
    </el-dialog>


    <el-dialog  :visible.sync="b_dialogFormVisible">
    // 任务3-1：区块链应用前端功能开发
    </el-dialog>

  </div>
</template>
  <script>
export default {
  data() {
    return {
      form: {

      },
      nowDate:'',
      info:{},
      userinfo:"张三",
      dialogFormVisible: false,
      b_dialogFormVisible: false,
      totalCount: 10,
      searchContent: '', //搜索内容
      currentPage: 1, // 当前页
      tableData: [

      ],
    }
  },
  mounted() {
    const date = new Date();
    this.nowDate = date.getFullYear() + "年" + (date.getMonth() + 1) + "月" + date.getDate() + "日";
  },
  created() {

    this.userinfo=localStorage.getItem("data")
    // this.form=localStorage.getItem("data")
    this.getinfo()
  },
  methods: {
    async createAppointment(){
      try {
        const response = await this.$http.get('/createAppointment', {
          params: {
            patientID: this.info.id,
            hospitalName: this.form.hospitalName,
            department:this.form.department
          },
        });
        alert(response['msg'])
        this.dialogFormVisible = false
      }catch (error) {
        console.info("error")
      }
    },
    handleLoginOut(){
      this.$router.replace({path:'/'})
    },
    // onSubmit(){},
    async onSubmit(){
      this.dialogFormVisible=true

    },
    async b_onSubmit(){
      // 任务3-1 完成Vue调用医疗健康病历查询接口API
    },
    async getinfo() {
      try {
        const response = await this.$http.get('/getPatientByIdentityNumber', {
          params: {
            identityNumber: localStorage.getItem("id")
          },
        });
            this.info=response
      } catch (error) {
        console.info("error")
      }

    },
  },
}
</script>
  <style lang="scss" scoped>

.container {
  padding: 20px;
}
.menu-bar {
  margin-bottom: 20px;
  align-items: center;
}

.add-button {
  margin-left: 20px;
}
.login-out{
  //float: right;
  margin-left: 1%;


}
.login-out button{
  //float: right;
  background-color: #ea6d6d;

}
.input-with-select{
  width: 300px;
}

</style>
