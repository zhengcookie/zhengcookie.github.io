<template>
  <div class="container">
    <div class="menu-bar">
      <div style="float: right;margin-left: 60%" ><span ></span></div>
      <div style="float: right">

        <el-button type="danger" @click="handleLoginOut">退出登录</el-button>
      </div>
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column prop="name" label="姓名" width="120">
        </el-table-column>
        <el-table-column prop="id" label="身份证号" width="200">
        </el-table-column>
        <el-table-column prop="gender" label="性别" width="80">
        </el-table-column>
        <el-table-column prop="accountAddress" label="钱包地址">
        </el-table-column>
        <el-table-column prop="age" label="年龄" width="150">
        </el-table-column>
        <el-table-column prop="hospitalName" label="医院" width="100">
        </el-table-column>
        <el-table-column prop="department" label="科室" width="150">
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="200">
          <template slot-scope="scope">
            <el-button type="text" @click="deleteacount(scope)" size="small">诊断</el-button>
            <el-button type="text" @click="payInsurance(scope)" size="small">结束诊断</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-pagination
        layout="prev, pager, next"
        :total="totalCount"
        :current-page="currentPage"
    >
    </el-pagination>

    <el-dialog  :visible.sync="dialogFormVisible">
      <div style="text-align: center"><h3>{{form.hospitalName}}</h3></div>
      <div style="text-align: center"><h3>门诊病历</h3></div>
      <el-row>
        <el-col :span="6">
          <span>姓名: {{form.name}}</span>
        </el-col>
        <el-col :span="6">
          <span>性别: {{form.gender}}</span>
        </el-col>
        <el-col :span="6">
          <span>科别: {{form.department}}</span>
        </el-col>
        <el-col :span="6">
          <span>日期: {{nowDate}}</span>
        </el-col>
      </el-row>
      <el-divider></el-divider>
      <el-form :model="form">
        <el-form-item  label="主诉" label-width="200px">
          <el-input  v-model="form.curhistoryzhusu" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="现病史" label-width="200px">
          <el-input v-model="form.curhistorycurrentMedicalHistory" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="既往史" label-width="200px">
          <el-input v-model="form.pastMedicalHistory" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="药物过敏史" label-width="200px">
          <el-input v-model="form.historyallergy" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="个人及家族历史" label-width="200px">
          <el-input v-model="form.historyphistory" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="体格检查" label-width="200px">
          <el-input v-model="form.historyphysique" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="辅导检查" label-width="200px">
          <el-input v-model="form.historyinspection" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="初步诊断" label-width="200px">
          <el-input v-model="form.curhistorydiagnosis" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="诊疗" label-width="200px">
          <el-input v-model="form.curhistorytreatment" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="addacount"
        >确 定</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>
<script>
export default {
  data() {
    return {
      form: {
      },
      nowDate: "",
      isPay:false,
      isdelete:false,
      dialogFormVisible: false,
      totalCount: 10,
      searchContent: '', //搜索内容
      currentPage: 1, // 当前页
      tableData: [

      ],
    }
  },
  mounted(){
    const date = new Date();
    this.nowDate = date.getFullYear() + "年" + (date.getMonth() + 1) + "月" + date.getDate() + "日";
    this.getList()
  },
  methods: {
    handleLoginOut(){
      this.$router.replace({path:'/'})
    },
    async payInsurance(scop){
      try {
        const response = await this.$http.get('/endMedicalConsultation', {
          params: {
            patientID: scop.row.id,
          },
        });

      } catch (error) {
        console.info("error")
      }
    },
    async deleteacount(scop){
      try {
        const response = await this.$http.get('/getMedicalRecordByIdentityNumber', {
          params: {
            patientID: scop.row.id,
            hospitalName: scop.row.hospitalName,
            department: scop.row.department,
            registrationInfo: ""
          },
        });
      this.form=response
      } catch (error) {
        console.info("error")
      }
      this.isdelete=true
      this.dialogFormVisible = true
    },
    async addacount(){
      console.info(this.form)


        try {
          await this.$http.post('/updateMedicalRecord', {
            data: {'form':this.form}
          });
          this.dialogFormVisible = false
        }catch (error) {
          console.info("error")
        }
        this.isdelete=false

    },
    async getList(){
      try {
        const response =await this.$http.get('/getPatientsList', {
        })
        this.tableData=response
      } catch (error) {
        console.info("error")
      }
    },
    async handleAdd() {
      try {
        const response = await this.$http.get('/getPension', {
          params: {
            id: this.searchContent,
            socialAddress: localStorage.getItem("address"),
          },
        });
        this.form.id=response["id"]
        this.form.joiningDate=response['joiningDate']
        this.form.contributionBase=response['contributionBase']
        this.form.salary=response['salary']
        this.form.name=response['name']
        this.dialogFormVisible = true
      } catch (error) {
        console.info("error")
      }

    },
  },
}
</script>
  <style lang="scss" scoped>
.container {
  padding: 20px;
}
.menu-bar {
  margin-bottom: 20px;
  align-items: center;
}
.search-bar {
  width: 300px;
}
.add-button {
  margin-left: 20px;
}
</style>
