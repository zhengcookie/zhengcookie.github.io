/*
 * @Author: taoyuqing
 * @Date: 2023-07-09 19:35:10
 * @Description:
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },
  {
    path: '/patient',
    name: 'patient',
    redirect: '/patientList',
    component: () => import('../views/patient.vue'),
    children: [
      {
        path: '/patientList',
        name: 'socialList',
        component: () => import('../views/patientList.vue'),
      },
      {
        path: '/patientSetting',
        name: 'patientSetting',
        component: () => import('../views/patient.vue'),
      },
    ],
  },
  {
    path: '/employer',
    name: 'employer',
    component: () => import('../views/Employer.vue'),
  }
]

const router = new VueRouter({
  routes,
})

export default router
