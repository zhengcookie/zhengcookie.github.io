
<template >
  <div class="container">
    <div style="margin-top: 10%;width:30%;background-color: white ">
      <div style="padding: 10px 20px 30px 40px;">
        <h2 style="color: chocolate;text-align:center">区块链医疗平台</h2>
        <div class="input-address-wrap">
          <el-input v-model="input" placeholder="请输入账户地址"></el-input>
        </div>
        <div class="input-role-wrap">
          <el-select v-model="value" placeholder="请选择角色">
            <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div class="input-wrap">
          <el-button type="primary" @click="handleLogin">登录</el-button>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
export default {
  name: 'HomeView',
  components: {},
  data() {
    return {
      options: [
        {
          value: '1',
          label: '患者登录',
        },
        {
          value: '2',
          label: '医生登录',
        },

      ],
      value: '',
      input: '',
    }
  },
  methods: {
    async handleLogin() {
      if (this.value === '0') {
        this.$router.push({ path: '/adminPage' })
      }
      if (this.value === '1') {
        try {
          await this.$http.get('/login', {
            params: {
              address: this.input,
              type: 'patient',
            },
          }).then(response => {
            const data = response; // 获取请求结果的数据
            // console.info(data[''])
            // 将请求结果保存到LocalStorage中
            localStorage.setItem('address', this.input);
            localStorage.setItem('data', data['name']);
            localStorage.setItem('id', data['id']);
          })

          this.$router.push({ path: '/patient' })
        } catch (error) {}
      }
      if (this.value === '2') {
        try {
          const response =await this.$http.get('/login', {
            params: {
              address: this.input,
              type: 'doctor',
            },
          })
          localStorage.setItem('address', this.input);
          this.$router.push({ path: '/employer' })
        } catch (error) {
          console.info("error")
        }

      }
    },
  },
}
</script>
<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: url("../assets/back.png");
  margin-bottom: 0px;

  height: 900px;
  background-size: 100% 100%;
}
.input-wrap {
  margin-top: 20px;
}
.el-select{
  width: 100%;
}
.el-button{
  width: 100%;
}
.input-address-wrap{
  margin-top: 20px;
  width: 100%;
}
.input-role-wrap{
  margin-top: 20px;
  width: 100%;
}
</style>
