/*
 * @Author: taoyuqing
 * @Date: 2023-07-10 01:15:05
 * @Description:
 */
import axios from 'axios'
const http = axios.create({
  baseURL: 'http://127.0.0.1:8089',
    // baseURL: 'http://192.168.36.2:10085/prod-api',
  headers: {
    'X-Requested-With': 'XMLHttpRequest',
    'Content-Type': 'application/json; charset=UTF-8',
  },
  timeout: 15000,
})
http.interceptors.request.use(
  (config) => {
    let newConfig = config
    return newConfig
  },
  (error) => {
    return Promise.reject(error)
  }
)
http.interceptors.response.use(
  (response) => {
    let res = response
    return res.data
  },
  (error) => {
    return Promise.reject(error)
  }
)

export default http
