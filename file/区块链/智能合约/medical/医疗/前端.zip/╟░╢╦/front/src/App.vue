<!--
 * @Author: taoyuqing
 * @Date: 2023-07-09 19:35:10
 * @Description:
-->
<template>
  <div id="app">

    <router-view/>
  </div>
</template>

<style lang="scss">
  #app{

  }
</style>
