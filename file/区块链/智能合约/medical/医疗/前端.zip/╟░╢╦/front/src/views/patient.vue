
<template>
  <div class="about">
    <div class="menu-wrap">
      <el-menu
          default-active="/patientList"
          class="el-menu-vertical-demo"
          @select="handleSelect">
<!--  -->
        <el-menu-item index="/patientList">
          <i class="el-icon-tickets"></i>
          <span slot="title">个人中心</span>
        </el-menu-item>
      </el-menu>
    </div>
    <div class="child-page">
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      totalCount: 10,
      searchContent: '', //搜索内容
      currentPage: 1, // 当前页
      tableData: [],
    }
  },
  methods: {
    handleSelect(path) {
      if (this.$route.path === path) {
        return
      }
      this.$router.push({
        path
      });
    },
  },
}
</script>
<style lang="scss" scoped>
.about{
  display: flex;
  // width: 100vw;
}
.child-page{
  margin-left: 20px;
  margin-top: 20px;
  width: calc(100% - 240px);
}
.menu-wrap{
  width: 200px;
  height: 100vh;
}
.menu-bar {
  display: flex;
  margin-bottom: 20px;
}
.search-bar {
  width: 300px;
}
.add-button{
  margin-left: 20px;
}
</style>
<style>
.el-menu{
  height:100%
}
</style>
